# Offline audit: I-GOD ADX/AO turns Phase1

NO TESTABLE. SHADOW ONLY. TRADE AUTHORITY: NONE.

Contains unchanged public-source mathematical dependencies, frozen protocol,
all six cells and ALL/Q75/Q90, all favorable/unfavorable outcomes and controls,
public raw data/NPZ/checksums and current Bitunix unsigned metadata receipts.
No credentials, private account data, network evaluator or runtime integration.

Python3.12 with NumPy2.3.5 and requests2.32.5 reproduces the published values.
requests is imported by inherited data.py but evaluation only uses its offline loader.

1. `python verify_manifest.py`
2. `python -m unittest research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.test_turns.CausalTests research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.test_turns.InferenceTests research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.test_turns.OutcomeTests -v`
3. `python -m research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.evaluate --cache market_cache --out reproduced`
4. Compare every reproduced artifact byte-for-byte to `research/confluence_1h_phase2/event_proximity/strict_series_audit/turn_intensity_phase1/artifacts/`.

Git/source boundary tests additionally require cloning the repository with full
history at the PR HEAD, including protocol commit a6b3cfb; they cannot be certified
from a ZIP without Git history. Full global suite also requires the original
repository and its dependencies. Synthetic unit tests are not independent platform evidence.

No management/TP1/trailing backtest is included. risk_stress_illustrative.csv is
explicit arithmetic with illustrative prices, not historical trades or an exact
Bitunix liquidation model. The planned forward cohort has not been activated.
