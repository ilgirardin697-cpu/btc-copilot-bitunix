"""One-off historical public download; no schedule/service/private endpoints."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,io,json,zipfile,time
import numpy as np
import requests
import argparse
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);OUT=p.parse_args().out.resolve();OUT.mkdir(parents=True,exist_ok=True)
SOURCE='https://data.binance.vision/data/futures/um/monthly/klines/BTCUSDT/1m/'
def get(url,params=None):
    assert url.startswith(SOURCE) or url in ('https://fapi.binance.com/fapi/v1/time','https://fapi.binance.com/fapi/v1/klines')
    start=datetime.now(timezone.utc).isoformat()
    with requests.Session() as s:
        s.trust_env=False;r=s.get(url,params=params,timeout=45,allow_redirects=False)
    meta=dict(url=url,params=params or {},status=r.status_code,requested_at=start,received_at=datetime.now(timezone.utc).isoformat(),bytes=len(r.content),sha256=hashlib.sha256(r.content).hexdigest())
    if r.status_code!=200:raise ValueError('PUBLIC_HTTP_'+str(r.status_code))
    if len(r.content)>30_000_000:raise ValueError('BOUNDED_BODY_LIMIT')
    return r.content,meta
def month(name):
    filename='BTCUSDT-1m-'+name+'.zip';p=OUT/filename;c=OUT/(filename+'.CHECKSUM')
    if p.exists() and c.exists():raw=p.read_bytes();check=c.read_bytes();receipt=json.loads((OUT/(filename+'.receipt.json')).read_text())
    else:
        check,_=get(SOURCE+filename+'.CHECKSUM');raw,receipt=get(SOURCE+filename)
        assert hashlib.sha256(raw).hexdigest()==check.decode().split()[0]
        p.write_bytes(raw);c.write_bytes(check);(OUT/(filename+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
    assert hashlib.sha256(raw).hexdigest()==check.decode().split()[0]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist();assert len(names)==1;csv=z.read(names[0])
    header=csv.split(b'\n',1)[0];skip=0 if header[:1].isdigit() else 1
    a=np.loadtxt(io.BytesIO(csv),delimiter=',',skiprows=skip,usecols=(0,1,2,3,4,5))
    assert a.shape[1]==6 and np.isfinite(a).all() and np.all(a[:,0]%60000==0) and np.all(np.diff(a[:,0])==60000)
    assert np.all(a[:,2]>=np.maximum(a[:,1],a[:,4])) and np.all(a[:,3]<=np.minimum(a[:,1],a[:,4]))
    return a,dict(month=name,rows=len(a),first_open=int(a[0,0]),last_open=int(a[-1,0]),official_checksum=check.decode().strip(),receipt=receipt)
names=[f'{y}-{m:02}' for y in range(2022,2027) for m in range(1,13) if '2022-11'<=f'{y}-{m:02}'<='2026-10']
with ThreadPoolExecutor(max_workers=4) as pool:items=list(pool.map(month,names))
a=np.concatenate([x[0] for x in items]);assert np.all(np.diff(a[:,0])==60000)
np.savez_compressed(OUT/'minutes.npz',bars=a)
m=dict(venue='BINANCE_USDM_PERPETUAL',symbol='BTCUSDT',interval='1m',rows=len(a),first_open=int(a[0,0]),last_open=int(a[-1,0]),months=[x[1] for x in items],npz_sha256=hashlib.sha256((OUT/'minutes.npz').read_bytes()).hexdigest(),one_off_historical_only=True)
(OUT/'minute_manifest.json').write_text(json.dumps(m,indent=2)+'\n',newline='\n');print(json.dumps({k:v for k,v in m.items() if k!='months'}),flush=True)
# A diagnostic extension only, never part of the four-year outcome study.
try:
    raw,receipt=get('https://fapi.binance.com/fapi/v1/time');server=json.loads(raw)['serverTime'];end=server//3600000*3600000-1
    start=int(datetime(2026,10,31,tzinfo=timezone.utc).timestamp()*1000)
    params=dict(symbol='BTCUSDT',interval='1h',startTime=start,endTime=end,limit=1500)
    body,receipt=get('https://fapi.binance.com/fapi/v1/klines',params)
    (OUT/'diagnostic_H1.json').write_bytes(body);(OUT/'diagnostic_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
    print('DIAGNOSTIC_PUBLIC_STATUS_200',len(json.loads(body)),flush=True)
except Exception as e:
    (OUT/'diagnostic_failure.json').write_text(json.dumps(dict(code=str(e) if str(e).startswith('PUBLIC_HTTP_') else type(e).__name__,not_a_strategy_result=True))+'\n')
    print('DIAGNOSTIC_NOT_AVAILABLE',type(e).__name__,flush=True)
