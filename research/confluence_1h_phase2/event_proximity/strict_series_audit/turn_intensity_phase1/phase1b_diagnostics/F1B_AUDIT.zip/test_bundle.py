import unittest
from importlib import import_module
m=import_module('research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.phase1b_diagnostics.test_phase1b')
suite=unittest.defaultTestLoader.loadTestsFromModule(m)
def flatten(s):
    for t in s:
        if isinstance(t,unittest.TestSuite):yield from flatten(t)
        else:yield t
keep=unittest.TestSuite(t for t in flatten(suite) if not t.id().endswith('test_frozen_detector_protocol_and_previous_files_unchanged'))
r=unittest.TextTestRunner(verbosity=2).run(keep)
raise SystemExit(not r.wasSuccessful())
