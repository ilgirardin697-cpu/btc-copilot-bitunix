# I-GOD Phase1B: frozen detector diagnostics

PR50 unchanged, NO TESTABLE. No new strategy, trading, capture or runtime integration.

Python3.12 / NumPy2.3.5 / requests2.32.5, Europe/Madrid zoneinfo required.
Optional Matplotlib to regenerate plots. Four-year market_cache contains NPZ,
153 raw input sources, official archive checksum files and original manifest.
Earlier diagnostic raw bytes and newer unsigned public response receipts included.
Old receipt limitations are retained, never upgraded to prospective evidence.

1. `python verify_manifest.py`
2. `python test_bundle.py` (all new tests except Git-history preservation)
3. `python -m research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.phase1b_diagnostics.evaluate --cache market_cache --out reproduced`
4. `python -m research.confluence_1h_phase2.event_proximity.strict_series_audit.turn_intensity_phase1.phase1b_diagnostics.supplement --out reproduced`
5. Compare reproduced numeric files byte-for-byte to `research/confluence_1h_phase2/event_proximity/strict_series_audit/turn_intensity_phase1/phase1b_diagnostics/artifacts/`.

Source preservation / global safety guards require the full repository with Git
history at the new PR HEAD; they are not certified by extracting a ZIP alone.

Original November capture190 rows remains separate. Later completion192 rows
includes only final requested closed hour, receipts dated16Nov. Neither is a
forward cohort. Hypothetical early/hindsight entries are not executable strategy
results. Phase1 no-stop returns use percent/ATR, not R. VIP0 fee sensitivity retains
Binance funding, does not pretend observed Bitunix fills or account commissions.

No2019 extension. No TP1/break-even/trailing manager. SHADOW ONLY. TRADE AUTHORITY:NONE.
Windows: extract in a short folder to avoid path length limits.
