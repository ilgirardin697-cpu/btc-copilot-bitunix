# I-GOD F4A / Claude independent audit package

SHADOW ONLY. TRADE AUTHORITY: NONE.
Main report: research/confluence_1h_phase2/event_proximity/strict_series_audit/F4A_RESULTS.md
All eight requested PR48 files are byte-exact from384032d; manifests distinguish origins.
This ZIP was prepared for review, never automatically sent to another service.

1. python verify_bundle.py
2. Install audit_requirements.txt in an isolated environment if needed (not production).
3. python -m research.confluence_1h_phase2.event_proximity.strict_series_audit.evaluate --cache market_cache --out reproduced_results
4. Compare reproduced_results CSV/GZ/JSON against the supplied artifacts; run metadata may refer to your own Git checkout.
5. python -m unittest research.confluence_1h_phase2.event_proximity.strict_series_audit.test_strict_series.NumericalTests research.confluence_1h_phase2.event_proximity.strict_series_audit.test_strict_series.ObservedRunTests -v

IsolationTests and all production regressions require the complete repository/Git history.
Their actual results are recorded in F4A validation.json, not asserted as independently repeated by Claude.
Sources use the unchanged PR46 loader, indicators, engine, funding treatment and statistical controls.
No new variants, proximity windows, ADX-trough rules or failed-rebound filters are evaluated.
Only the crossed series and its prior sign change to pececillos; red EMA(tendencia) is retained.
Seven unique signals are evaluated under two co-primary targets, not14 independent opportunities.
FULL contains only seven trades, TEST one loss; no virgin historical holdout and no validated edge.
Conservative/optimistic funding scenarios are not exact net estimates where marks are missing.
All CSV trades/equity are SIMULATED, never account records or live fills.
No credentials, private account data, trading API or deployment configuration in this package.
