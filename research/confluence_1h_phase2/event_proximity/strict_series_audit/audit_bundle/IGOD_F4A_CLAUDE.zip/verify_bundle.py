from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'BUNDLE_MANIFEST.json').read_text())
for name,item in m['files'].items():
    path=(root/name).resolve()
    assert path.is_relative_to(root.resolve()),'INVALID_PATH'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],name
print(json.dumps({'verified_files':len(m['files']),'requested_pr48_files':len(m['requested_pr48_files']),'trade_authority':'NONE'}))
